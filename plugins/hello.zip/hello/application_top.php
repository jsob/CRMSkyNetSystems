<?php

 
require('plugins/hello/classes/my_class.php');