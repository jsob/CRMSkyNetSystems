<?php

define('TEXT_PLUGIN_HELLO_WORLD','Hello, world!');
define('TEXT_PLUGIN_SEND_MESSAGE','Send Message');
define('TEXT_PLUGIN_MESSAGE','Message');