<?php

define('TEXT_PLUGIN_HELLO_WORLD','Привет, мир!');
define('TEXT_PLUGIN_SEND_MESSAGE','Отправить сообщение');
define('TEXT_PLUGIN_MESSAGE','Сообщение');